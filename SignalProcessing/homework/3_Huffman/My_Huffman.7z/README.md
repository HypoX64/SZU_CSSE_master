@Hypo,雷海波 1910273011
* run my_Huffman
```shell
python my_Huffman.py
```
* result:
```shell
Origin input: ACBDEAAABCDE
Encode huffman: 1011001001111010100111000111
Decode huffman: ACBDEAAABCDE
```

